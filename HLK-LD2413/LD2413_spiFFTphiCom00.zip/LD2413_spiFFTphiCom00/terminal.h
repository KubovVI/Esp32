boolean comEnable;

void checkCom(){
  static char comBuf[3];
  if (!Serial.available()) return;
  while(Serial.available()){
    comBuf[0]=comBuf[1]; comBuf[1]=comBuf[2]; 
    comBuf[2]=Serial.read();
  }//while 
  if (String(comBuf)=="###"){ comEnable=true;
    Serial.println("Start Terminal");
  }//if String
}//checkCom

void updateCom(){
  char c;
  while(Serial.available()){ c=Serial.read(); hSerial.write(c);}
  while(hSerial.available()){ c=hSerial.read(); Serial.write(c);} 
}//updateCom